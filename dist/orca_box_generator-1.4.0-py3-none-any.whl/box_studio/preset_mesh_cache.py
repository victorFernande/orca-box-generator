"""Lossless, source-bound canonical surfaces for the three standard boxes.

Only exact manufacturing parameters may use these reviewed package resources.
Every other design, or an unavailable/stale/damaged resource, uses the generator.
The controller's existing byte-bounded LRU owns decoded meshes; this module does
not retain a second decoded cache or load the entire library at startup.
"""
from __future__ import annotations

import base64
import hashlib
import io
import json
from pathlib import Path
import re
import zipfile

from .schema import normalize_params
from .mesh_generator import MeshData, np
from .preset_mesh_index import PRESET_MESH_SOURCE_HASH, PRESET_MESH_INDEX

# Replaced by the bundler only after checking the source/resource fingerprints.
_BUNDLED_PRESET_DATA = {}
_BUNDLED_PRESET_RAW_HASH = ""
_BUNDLED_PRESET_CODE_HASH = ""
_PRESET_DEPENDENCIES = ("schema.py", "mesh_generator.py", "presets_catalog.py", "rugged_geometry.py", "rugged_latch_geometry.py", "rugged_front_geometry.py", "rugged_front_mesh.py")
_PRESET_SOURCE_CHECK = None


def preset_parameter_key(raw):
    p = normalize_params(raw)
    return json.dumps({k: v for k, v in p.items() if k not in (
        "name", "lang", "theme", "export_target", "auto_configure_slicer"
    )}, sort_keys=True)


def preset_source_fingerprint(parts):
    digest = hashlib.sha256()
    for name in _PRESET_DEPENDENCIES:
        digest.update(name.encode("ascii") + b"\0")
        digest.update(parts[name].replace(b"\r\n", b"\n"))
    return digest.hexdigest()


def _preset_sources_match():
    global _PRESET_SOURCE_CHECK
    location = Path(__file__).resolve()
    try:
        paths = [location] if _BUNDLED_PRESET_DATA else [location.with_name(n) for n in _PRESET_DEPENDENCIES]
        token = tuple((str(p), p.stat().st_size, p.stat().st_mtime_ns) for p in paths)
        if _PRESET_SOURCE_CHECK is not None and _PRESET_SOURCE_CHECK[0] == token:
            return _PRESET_SOURCE_CHECK[1]
        if _BUNDLED_PRESET_DATA:
            source = location.read_bytes().replace(b"\r\n", b"\n")
            parts = {}
            for name in _PRESET_DEPENDENCIES:
                start = ("# BOX_GEOMETRY_SOURCE_BEGIN " + name + "\n").encode("ascii")
                end = ("# BOX_GEOMETRY_SOURCE_END " + name + "\n").encode("ascii")
                if source.count(start) != 1 or source.count(end) != 1:
                    return False
                parts[name] = source.split(start, 1)[1].split(end, 1)[0]
            valid = (PRESET_MESH_SOURCE_HASH == _BUNDLED_PRESET_RAW_HASH and
                     preset_source_fingerprint(parts) == _BUNDLED_PRESET_CODE_HASH)
        else:
            valid = preset_source_fingerprint({p.name: p.read_bytes() for p in paths}) == PRESET_MESH_SOURCE_HASH
        _PRESET_SOURCE_CHECK = (token, valid)
        return valid
    except (OSError, ValueError):
        return False


def load_standard_preset_mesh(raw, part, reuse_from=None):
    """Return an exact, already validated package surface, or None on a miss.

    A digest is checked both before decompression and after reconstructing each
    original array. XOR on float bits and integer deltas are reversible, without
    quantization, smoothing, triangle removal or a change of coordinate order.
    Byte planes improve DEFLATE locality. An exactly translated part can reuse
    a source blob; its independently approved final vertex digest still applies.
    No trust decision is accepted from a UI message or a user-preset file.
    A caller-owned immutable mesh may share exactly hash-matching index/normal
    arrays. This function retains no decoded array after returning.
    """
    key = hashlib.sha256(preset_parameter_key(raw).encode("utf-8")).hexdigest()
    design = PRESET_MESH_INDEX.get(key)
    entry = design.get("parts", {}).get(part) if design else None
    if not entry or not _preset_sources_match():
        return None
    try:
        filename = entry["file"]
        if not re.fullmatch(r"[a-z0-9_]+-[a-z0-9_]+\.npz", filename):
            return None
        if _BUNDLED_PRESET_DATA:
            blob = base64.b64decode(_BUNDLED_PRESET_DATA[filename], validate=True)
        else:
            blob = (Path(__file__).resolve().parent / "preset_meshes" / filename).read_bytes()
        if len(blob) != entry["size_bytes"] or hashlib.sha256(blob).hexdigest() != entry["sha256"]:
            return None
        vertices_count, faces_count = entry["vertices"], entry["triangles"]
        if not (0 < vertices_count <= 5_000_000 and 0 < faces_count <= 10_000_000):
            return None
        expected = {"vertices": (vertices_count, "<u4"),
                    "triangles": (faces_count, "<i4"), "normals": (faces_count, "<u4")}
        encoding = entry.get("encoding", "xor-delta-v1")
        if encoding not in ("xor-delta-v1", "xor-delta-shuffle12-v1"):
            return None
        translation = entry.get("vertex_translation")
        if translation is not None:
            translation = np.asarray(translation, dtype="<f4")
            if (translation.shape != (3,) or not np.isfinite(translation).all()
                    or not re.fullmatch(r"[0-9a-f]{64}", entry.get("vertex_source_sha256", ""))):
                return None
        with zipfile.ZipFile(io.BytesIO(blob)) as archive:
            if set(archive.namelist()) != {name + ".npy" for name in expected}:
                return None
            if any(archive.getinfo(name + ".npy").file_size > count * 12 + 1024
                   for name, (count, _) in expected.items()):
                return None
        arrays = {}
        with np.load(io.BytesIO(blob), allow_pickle=False) as archive:
            for name, (count, dtype) in expected.items():
                attribute = {"triangles": "triangles", "normals": "face_normals"}.get(name)
                reusable = getattr(reuse_from, attribute, None) if attribute else None
                decoded_dtype = "<i4" if name == "triangles" else "<f4"
                if (isinstance(reusable, np.ndarray) and reusable.shape == (count, 3)
                        and reusable.dtype == np.dtype(decoded_dtype)
                        and reusable.flags.c_contiguous and not reusable.flags.writeable
                        and hashlib.sha256(memoryview(reusable).cast("B")).hexdigest()
                        == entry["array_sha256"][name]):
                    arrays[name] = reusable
                    continue
                source_vertices = getattr(reuse_from, "vertices", None) if name == "vertices" else None
                if (translation is not None and isinstance(source_vertices, np.ndarray)
                        and source_vertices.shape == (count, 3)
                        and source_vertices.dtype == np.dtype("<f4")
                        and source_vertices.flags.c_contiguous and not source_vertices.flags.writeable
                        and hashlib.sha256(memoryview(source_vertices).cast("B")).hexdigest()
                        == entry["vertex_source_sha256"]):
                    array = source_vertices.copy()
                else:
                    encoded = archive[name]
                    if encoding == "xor-delta-shuffle12-v1":
                        if (encoded.shape != (4, 3, count) or encoded.dtype != np.dtype("u1")
                                or not encoded.flags.c_contiguous):
                            return None
                        words = np.empty((count, 3), dtype="<u4")
                        words.view("u1").reshape(count, 3, 4)[:] = encoded.transpose(2, 1, 0)
                        del encoded
                        encoded = words.view(dtype).reshape(-1) if name == "triangles" else words
                    else:
                        shape = (count * 3,) if name == "triangles" else (count, 3)
                        if (encoded.shape != shape or encoded.dtype != np.dtype(dtype)
                                or not encoded.flags.c_contiguous):
                            return None
                    if name == "triangles":
                        # Modular accumulation preserves the original int32 bits.
                        np.cumsum(encoded, dtype="<i4", out=encoded)
                        array = encoded.reshape(-1, 3)
                    else:
                        np.bitwise_xor.accumulate(encoded, axis=0, out=encoded)
                        array = encoded.view("<f4")
                    del encoded
                if name == "vertices" and translation is not None:
                    np.add(array, translation, out=array)
                if hashlib.sha256(memoryview(array).cast("B")).hexdigest() != entry["array_sha256"][name]:
                    return None
                arrays[name] = array
        vertices, triangles, normals = (arrays[name] for name in ("vertices", "triangles", "normals"))
        report = entry["topology"]
        if (not np.isfinite(vertices).all() or not np.isfinite(normals).all() or
                triangles.min() < 0 or triangles.max() >= vertices_count or
                not report["closed"] or not report["oriented"] or
                report["vertices"] != vertices_count or report["triangles"] != faces_count or
                not np.isfinite(entry["volume_cm3"]) or entry["volume_cm3"] <= 0):
            return None
        for array in arrays.values():
            array.flags.writeable = False
        bounds = {key: list(value) for key, value in entry["bounds_mm"].items()}
        return MeshData(vertices, triangles, normals, bounds, entry["volume_cm3"],
                        part, entry["interface_error_mm"])
    except (OSError, ValueError, KeyError, TypeError, OverflowError, EOFError, zipfile.BadZipFile):
        return None
